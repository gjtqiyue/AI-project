package student_player_v2;

import boardgame.Move;
import java.util.ArrayList;
import java.util.Iterator;
import java.lang.*;

import pentago_swap.PentagoPlayer;
import pentago_swap.PentagoBoardState;
import pentago_swap.PentagoMove;

public class MyTools {

	

}